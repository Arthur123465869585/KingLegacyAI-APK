const ids=["level","beli","gems","plan"];
const status=document.getElementById("status");
function load(){
  ids.forEach(id=>{const el=document.getElementById(id);el.value=localStorage.getItem("kla_"+id)||"";});
  document.querySelectorAll("[data-task]").forEach(el=>el.checked=localStorage.getItem("kla_task_"+el.dataset.task)==="1");
}
document.getElementById("save").addEventListener("click",()=>{
  ids.forEach(id=>localStorage.setItem("kla_"+id,document.getElementById(id).value));
  document.querySelectorAll("[data-task]").forEach(el=>localStorage.setItem("kla_task_"+el.dataset.task,el.checked?"1":"0"));
  status.textContent="Progresso salvo neste dispositivo!";
});
load();
